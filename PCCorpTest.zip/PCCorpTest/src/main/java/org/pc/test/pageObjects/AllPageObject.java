package org.pc.test.pageObjects;

import org.pc.test.seleniumDriverOperations.DesktopWebDriver;
import org.pc.test.seleniumDriverOperations.TestWebDriver;

public class AllPageObject {
	public static TestWebDriver driver;
	public static HomePage homePage;
	public static FinancialPage finalcialPage;
	public static SignUpPage signUpPage;

	public static void LoadDesktop(String url,String bType)
	{
		driver= new DesktopWebDriver(bType);
		homePage= new HomePage(driver,url);
		finalcialPage=new FinancialPage(driver);
		signUpPage=new SignUpPage(driver);
	}

}

package org.pc.test.config;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.pc.test.pageObjects.AllPageObject;


public class ConfigReader {
	Properties properties;
	
	public static boolean read()
	{
		 Properties prop;
		prop=new Properties();
		InputStream input=null;
		String url="";
		try
		{
			input=new FileInputStream("C:\\Users\\VGS\\workspace\\PCCorpTest\\src\\main\\java\\org\\pc\\test\\config\\config.properties");
			prop.load(input);
			url=prop.getProperty("Url");
			if(prop.getProperty("Browser").equals("desktop"))
				AllPageObject.LoadDesktop(url,prop.getProperty("BrowserType"));
			return true;
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
		finally{
			if(input!=null)
			{
				try
				{
					input.close();
				}
				catch(IOException e)
				{
					e.printStackTrace();
				}
			}
		}
		return false;
	}
	
}

package org.pc.test.seleniumDriverOperations;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class DesktopWebDriver implements TestWebDriver {
	WebDriver driver;
	static String driverPath = "C:\\Users\\VGS\\workspace\\PCCorpTest\\chromedriver.exe" ;
	String bType="";

	public DesktopWebDriver(String browserType)
	{
		bType=browserType;
		
		if(browserType.equals("chrome"))
		{
			driver = initChromeDriver();
		}
		if(browserType.equals("firefox"))
		{
			driver=initFirefoxDriver();
		}
	}


	private static WebDriver initChromeDriver() {
		//System.out.println("Launching google chrome with new profile..");
		System.setProperty("webdriver.chrome.driver", driverPath);
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		//driver.navigate().to(appURL);
		return driver;
	}

	private static WebDriver initFirefoxDriver() {
		//System.out.println("Launching Firefox browser..");
		WebDriver driver = new FirefoxDriver();
		driver.manage().window().maximize();
		//driver.navigate().to(appURL);
		return driver;
	}
	public void NavigateToUrl(String url)
	{
		driver.navigate().to(url);
	}
	
	public void ClickByID(String Id)
	{
		driver.findElement(By.id(Id)).click();
	}
	public void SelectCheckBox(String Role)
	{
		driver.findElement(By.className(Role)).click();
	}
	public void ClickByXpath(String Xpath)
	{
		driver.findElement(By.xpath(Xpath)).click();
	}	
	public void EnterById(String id,String value)
	{
		driver.findElement(By.id(id)).sendKeys(value);
	}
}

package org.pc.test.pageObjects;

import org.pc.test.seleniumDriverOperations.TestWebDriver;

interface IHomePage
{
	public void LoadHomePage();
	public FinancialPage LoadFinancialPage();
}

public class HomePage implements IHomePage {
	TestWebDriver Driver;
	public String url="";
	public static String financialToolsXpath="//a[text()='FINANCIAL TOOLS']";
	FinancialPage fpage=null;
	public HomePage(TestWebDriver driver,String url)
	{
		Driver=driver;
		this.url=url;	
	}
	public void LoadHomePage()
	{
		Driver.NavigateToUrl(url);
	}
	
	public FinancialPage LoadFinancialPage()
	{
		Driver.ClickByXpath(financialToolsXpath);
		return new FinancialPage(Driver);
	}
	
}

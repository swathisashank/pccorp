package org.pc.test.seleniumDriverOperations;

import org.openqa.selenium.WebDriver;

public interface TestWebDriver {
	WebDriver driver=null;
	public void NavigateToUrl(String url);
	public void ClickByID(String Id);
	public void SelectCheckBox(String Role);
	public void ClickByXpath(String Xpath);
	public void EnterById(String id,String value);

}

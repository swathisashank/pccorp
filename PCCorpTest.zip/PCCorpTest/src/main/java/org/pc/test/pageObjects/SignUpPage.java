package org.pc.test.pageObjects;

import org.pc.test.config.ConfigReader;
import org.pc.test.seleniumDriverOperations.TestWebDriver;

interface ISignUpPage
{
	public void enterUserName(String email);
	public void enterPassword(String password);
	public void enterPhoneNumber(String phonenum);
}
public class SignUpPage implements ISignUpPage {
	TestWebDriver Driver;
	public static String emailFieldID ="username";
	public static String passwordFieldID="passwd";
	public static String phoneNumberID="phoneNumber";
	
	
	public SignUpPage(TestWebDriver driver)
		{
			this.Driver=driver;
			//ConfigReader.read();
		}
	
	public void enterUserName(String email)
	{
		Driver.EnterById(emailFieldID, email);
		
	}
	public void enterPassword(String password)
	{
		Driver.EnterById(passwordFieldID,password);
	}
	public void enterPhoneNumber(String phonenum)
	{
			Driver.EnterById(phoneNumberID,phonenum);
	}
	
}

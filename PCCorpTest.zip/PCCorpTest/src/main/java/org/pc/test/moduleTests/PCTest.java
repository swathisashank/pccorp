package org.pc.test.moduleTests;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.WebDriver;
import org.pc.test.config.ConfigReader;
import org.pc.test.pageObjects.AllPageObject;
import org.pc.test.pageObjects.FinancialPage;
import org.pc.test.pageObjects.HomePage;
import org.pc.test.pageObjects.SignUpPage;
import org.pc.test.seleniumDriverOperations.TestWebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class PCTest {
	public HomePage homepage;
	public FinancialPage financePage;
	public SignUpPage signUpPage;
	
	WebDriver driver;
	public PCTest()
	{
		ConfigReader.read();
		
	}
	@BeforeTest
	public void gearUp()
	{
		try{
			login();
		}
		catch(Throwable e)
		{
			e.printStackTrace();
		}
	}
	
	@Test
	public  void testScript()
	{
		
		try
		{
			financePage=AllPageObject.homePage.LoadFinancialPage();
			signUpPage=AllPageObject.finalcialPage.clickSignUpButton();
			signUpPage.enterUserName("Test@gmail.com");
			signUpPage.enterPassword("Password123");
			signUpPage.enterPhoneNumber("8746752345");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
		
	public void login() throws Throwable{
		AllPageObject.homePage.LoadHomePage();	
	}

	
	@AfterTest
	public void close()
	{
		
	}
}

package org.pc.test.pageObjects;

import org.pc.test.seleniumDriverOperations.TestWebDriver;

public class FinancialPage {
	TestWebDriver Driver;
	public static String signUpButtonXpath="//a[text()='SIGN UP']";
	public FinancialPage(TestWebDriver driver)
	{
		this.Driver=driver;
	}
	public SignUpPage clickSignUpButton()
	{
		Driver.ClickByXpath(signUpButtonXpath);
		return new SignUpPage(Driver);
	}
}
